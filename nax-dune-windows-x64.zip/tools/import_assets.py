"""Import local game data; never execute DOS programs or redistribute assets."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import zipfile

LIMIT = 128 * 1024 * 1024


def safe_name(name: str) -> PurePosixPath:
    p = PurePosixPath(name.replace("\\", "/"))
    if p.is_absolute() or ".." in p.parts or ":" in name or not p.parts:
        raise ValueError(f"Unsafe archive path: {name!r}")
    return p


def read_zip(path: Path) -> dict[str, bytes]:
    with zipfile.ZipFile(path) as archive:
        if sum(i.file_size for i in archive.infolist()) > LIMIT:
            raise ValueError("Archive exceeds the 128 MiB import limit")
        files = {}
        for entry in archive.infolist():
            name = str(safe_name(entry.filename))
            if entry.is_dir():
                continue
            if name.casefold() in files:
                raise ValueError("Duplicate archive path")
            files[name.casefold()] = archive.read(entry)
        return files


def iso_files(raw: bytes) -> dict[str, bytes]:
    """Read bounded ISO9660 records from a single MODE1/2352 data track."""
    if len(raw) % 2352:
        raise ValueError("Truncated MODE1/2352 image")
    data = b"".join(raw[n + 16:n + 2064] for n in range(0, len(raw), 2352))
    pvd = data[16 * 2048:17 * 2048]
    if pvd[:7] != b"\x01CD001\x01":
        raise ValueError("Expected an ISO9660 primary volume descriptor")
    files: dict[str, bytes] = {}
    visited = set()

    def extent(record: bytes) -> bytes:
        start = int.from_bytes(record[2:6], "little") * 2048
        size = int.from_bytes(record[10:14], "little")
        if start + size > len(data):
            raise ValueError("ISO extent outside image")
        return data[start:start + size]

    def walk(record: bytes, parent: str, depth: int) -> None:
        if depth > 12 or record[2:6] in visited:
            raise ValueError("Cyclic or deeply nested ISO directory")
        visited.add(record[2:6])
        buf = extent(record)
        pos = 0
        while pos < len(buf):
            length = buf[pos]
            if length == 0:
                pos = (pos // 2048 + 1) * 2048
                continue
            r = buf[pos:pos + length]
            if length < 34 or len(r) != length or 33 + r[32] > length:
                raise ValueError("Invalid ISO directory record")
            pos += length
            name = r[33:33 + r[32]]
            if name in (b"\x00", b"\x01"):
                continue
            name = name.decode("ascii").split(";")[0].lower()
            if "/" in name or "\\" in name:
                raise ValueError("Invalid ISO filename")
            full = str(safe_name(parent + name))
            if r[25] & 2:
                walk(r, full + "/", depth + 1)
            else:
                if full in files:
                    raise ValueError("Duplicate ISO filename")
                files[full] = extent(r)

    walk(pvd[156:190], "", 0)
    return files


def import_game(game: str, archive: Path, destination: Path) -> dict:
    files = read_zip(archive)
    if game == "dune2":
        images = [b for n, b in files.items() if n.endswith(".img")]
        if len(images) != 1:
            raise ValueError("Expected exactly one MODE1/2352 CD image")
        files = iso_files(images[0])
        selected = {Path(n).name: b for n, b in files.items()
                    if n.startswith("virgin/dune2/") and
                    (n.endswith(".pak") or Path(n).name == "dune2.exe")}
        required = {"dune.pak", "english.pak", "scenario.pak", "dune2.exe"}
        if not required <= selected.keys():
            raise ValueError("Dune II CD is missing required game data")
    else:
        selected = {n.removeprefix("utopia/"): b for n, b in files.items()
                    if n.startswith("utopia/")}
        if not {"utopia.exe", "u.mdg", "scenario/level1.map"} <= selected.keys():
            raise ValueError("Utopia archive is missing required files")
    target = destination.resolve() / game
    # Refuse existing folders to prevent overwriting saves or following symlinks.
    if target.exists() or target.is_symlink():
        raise ValueError(f"Destination already exists: {target}")
    manifest = {"game": game, "source_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
                "files": {n: {"size": len(b), "sha256": hashlib.sha256(b).hexdigest()}
                          for n, b in sorted(selected.items())},
                "status": "assets imported; native engine validation required"}
    target.mkdir(parents=True)
    for name, content in selected.items():
        path = target.joinpath(*safe_name(name).parts)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)
    (target / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("game", choices=("dune2", "utopia"))
    parser.add_argument("archive", type=Path)
    parser.add_argument("--destination", type=Path, default=Path("local-data"))
    args = parser.parse_args()
    try:
        manifest = import_game(args.game, args.archive, args.destination)
    except (ValueError, OSError, zipfile.BadZipFile) as exc:
        parser.exit(1, f"Import failed: {exc}\n")
    print(f"Imported {len(manifest['files'])} files for {args.game}; no DOS code executed.")


if __name__ == "__main__":
    main()
