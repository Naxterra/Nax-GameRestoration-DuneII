$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
cmake -S $root -B "$root/build-windows" -A x64
if ($LASTEXITCODE -ne 0) { throw 'CMake configuration failed' }
cmake --build "$root/build-windows" --config Release --parallel 4
if ($LASTEXITCODE -ne 0) { throw 'Build failed' }
ctest --test-dir "$root/build-windows" -C Release --output-on-failure
if ($LASTEXITCODE -ne 0) { throw 'Tests failed' }
