$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$exe = "$root/build-windows/bin/Release/nax-dune.exe"
if (Test-Path "$root/nax-dune.exe") { $exe = "$root/nax-dune.exe" }
$data = "$root/local-data/dune2"
if (!(Test-Path $exe)) { throw 'Run scripts/build-windows.ps1 first.' }
if (!(Test-Path "$data/dune.pak")) { throw 'Import the Dune II archive first; see README.md.' }
$run = Join-Path $env:LOCALAPPDATA 'NaxGameRestoration/Dune2'
New-Item -ItemType Directory -Force $run | Out-Null
$ini = Join-Path $run 'opendune.ini'
if (!(Test-Path $ini)) {
    @"
[opendune]
datadir=$($data.Replace('\','/'))
savedir=$($run.Replace('\','/'))
language=english
scalefactor=3
scalefilter=nearest
fullscreen=0
framerate=60
dune2_enhanced=1
"@ | Set-Content -Encoding ascii $ini
}
Push-Location $run
try { & $exe; if ($LASTEXITCODE -ne 0) { throw "Dune II exited with $LASTEXITCODE. See $run/error.log" } }
finally { Pop-Location }
