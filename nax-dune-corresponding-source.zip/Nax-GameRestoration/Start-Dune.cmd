@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\play-dune.ps1" %*
if errorlevel 1 (
  echo.
  echo Dune II could not start. See the message above.
  pause
  exit /b 1
)
