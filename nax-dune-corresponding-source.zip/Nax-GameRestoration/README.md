# Nax Game Restoration

Native restoration work for Dune II and Utopia: The Creation of a Nation.
The priority is faithful gameplay, readable scaling, and modern window/input
handling. No DOSBox, DOS CPU interpreter, or virtual DOS environment is used.

**This is an initial Dune II port, not a completed restoration of both games.**

| Game | Implemented | Remaining |
| --- | --- | --- |
| Dune II | Native OpenDUNE engine, Windows x64 build, strict Direct3D 12 renderer selection, resizing, DPI-aware mouse conversion, desktop fullscreen, local CD import | Windows 11 GPU/audio/input testing, full campaign/save validation, further modern RTS controls |
| Utopia DOS | Safe local import and hashed inventory of the supplied files | Native game engine, format decoders, simulation, rendering, audio, controls, and gameplay validation |

SDL2 is used as a native platform/rendering library. On Windows the engine
selects its `direct3d12` driver explicitly, checks the selected driver name,
and fails if it cannot initialize it. An installed DX12 runtime alone does not
establish GPU support. Linux development builds may use other renderers for tests.

## Try the Windows build

Use Windows 11 x64 with a working DX12 graphics driver. Extract the **complete**
binary ZIP, then double-click **Start-Dune.cmd**. On the first start, select your
original `Dune-II-The-Building-of-a-Dynasty_DOS_EN_ISO-Version.zip` when prompted.
Windows PowerShell imports its data automatically; Python is not needed to play.
Use Start-Dune.cmd for subsequent launches as well.

The package contains the native player, not the original game data. Starting
`nax-dune.exe` directly before importing data cannot run the game. Missing or
incomplete PAK directories now produce instructions to use Start-Dune.cmd.

The importer reads ISO9660 files directly from the MODE1/2352 CD image. It does
not mount or execute the DOS installer. It imports 15 PAK files and `dune2.exe`
as original data; the native executable contains the game logic. Only the native
`nax-dune.exe` is launched.

The launcher imports data under `%LOCALAPPDATA%\NaxGameRestoration\Dune2\data`
and stores initial configuration and saves in its parent directory. Existing
imports under the package's `local-data/dune2` or `data` directory also work.
It repairs moved data paths, preserves other configuration and custom save
locations, and backs up existing configuration before its first update.
Incomplete imports are preserved; replacement imports use a fresh directory.
The player receives explicit data/save directory overrides from the launcher,
so an unrelated OpenDUNE configuration cannot redirect the selected paths.
Check `error.log` there for `Nax renderer: direct3d12`. That line confirms driver
selection; actual gameplay still needs to be checked on your hardware.
Run `./scripts/verify-windows.ps1` for timed intro-rendering and three-house
scenario checks on your GPU. It retains logs and an intro screenshot in a new
temporary folder, separately from your saves. Use an ASCII package path such as
`C:\Games\Nax`; Unicode data paths have not been validated in the legacy engine.

Resize the window to scale the picture. Alt+Enter or F11 toggles desktop
fullscreen; F1 opens Mentat, F2 options, F3 the selected structure menu. The
gameplay controls otherwise remain OpenDUNE's controls. New selection groups,
attack-move and remappable bindings have not been implemented.

## Build from source on Windows

Install Visual Studio 2022's Desktop development with C++ workload and a current
Windows SDK, CMake 3.24+, Git, and Python 3.10+. From a developer PowerShell:

```powershell
./scripts/build-windows.ps1
./Start-Dune.cmd
```

CMake downloads the pinned SDL2 2.32.10 source with SHA256 verification. The
vendored OpenDUNE revision and changes are recorded in THIRD_PARTY.md. The
Windows CI workflow builds the executable and runs importer tests; no CI run
or Windows runtime test is claimed by the local Linux validation.

## Linux development checks

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel 4
ctest --test-dir build --output-on-failure
```

On a headless build host use `-DSDL_X11=OFF -DSDL_WAYLAND=OFF -DSDL_KMSDRM=OFF`.
For functional checks, create a separate writable run directory containing:

```ini
[opendune]
datadir=/absolute/path/to/checkout/local-data/dune2
savedir=/absolute/path/to/run-directory
language=english
scalefactor=3
scalefilter=nearest
renderer_software_fallback=1
```

Run from that directory, with an external timeout:

```sh
SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy NAX_SMOKE_FRAMES=10 NAX_SMOKE_OUTPUT=intro.bmp timeout 20s /absolute/path/to/build/bin/nax-dune
SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy NAX_VALIDATE_SCENARIOS=1 timeout 30s /absolute/path/to/build/bin/nax-dune
```

Require exit status 0 **and** `NAX_SMOKE frames=10` with nonzero `nonblack_pixels`
for the render check, or `NAX_SCENARIOS_OK count=3` for scenario validation. A
timeout, zero-frame launch or missing marker is not a pass. These are opt-in
developer checks and do not validate audio, complete campaigns or mouse behavior.

Verified in this Linux workspace: native compilation; six Python importer tests
and four PowerShell import/startup integration tests (PowerShell 7.5.4);
16 Dune II and 163 Utopia imported file hashes; 960×600 intro rendering with
93,726 nonblack pixels; scenario 1 loading for Harkonnen (18 units), Atreides
(17 units), and Ordos (17 units), each with one structure. A Windows x64 executable
and SDL2 DLL were cross-compiled with Zig 0.14.1, including the D3D12 backend.
**The Windows executable has not been run on Windows 11.**
The PowerShell importer also imported the actual supplied CD archive, with all
16 resource hashes matching the Python import. The updated native player was
checked using these imported resources and explicit directory overrides.
The Windows file picker and batch entry point still need a Windows GUI check.

## Utopia status

```powershell
py -3 tools/import_assets.py utopia "C:\Games\Utopia-The-Creation-of-a-Nation_DOS_EN.zip"
```

This imports and inventories data only. It does not make Utopia playable.
The DOS archive includes an MZ launcher, executable modules (`u.mdg`, `i.mdg`),
compressed graphics/text/maps and audio drivers. No source code is present.

Research checked:

- https://github.com/bdgscotland/Utopia-Creation-of-a-Nation documents formats
  and has a save editor; its README describes the resource extractor as pending
  release. It does not supply a native game engine.
- https://github.com/linuxkafe/Utopia-SNES-Static-Recomp targets a separate SNES
  ROM, and its README reports unimplemented rendering/audio and no playable game.
  It cannot use the uploaded DOS assets as a replacement.

A DOS-compatible Utopia restoration needs a native engine reconstructed from
the original behavior, or usable engine source supplied separately. A DX12
window by itself would not implement the game's simulation. No placeholder
Utopia executable or emulator wrapper is included.

The original game data stays under ignored `local-data/`. The importer refuses
to overwrite an existing game folder, protecting any local changes. Preserve
that folder before intentionally reimporting. Do not commit original assets or
include them in source/build packages. See LICENSE and THIRD_PARTY.md for code
attribution and redistribution requirements.
