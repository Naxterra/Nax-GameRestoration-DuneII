param(
    [Parameter(Mandatory = $true)][string]$Archive,
    [Parameter(Mandatory = $true)][string]$Destination
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2
Add-Type -AssemblyName System.IO.Compression.FileSystem

# Import only named game resources, never arbitrary archive paths.
$destinationPath = [IO.Path]::GetFullPath($Destination)
if (Test-Path -LiteralPath $destinationPath) { throw "Destination already exists; preserving it: $destinationPath" }
$zip = [IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($Archive))
try {
    $total = 0L
    foreach ($entry in $zip.Entries) { $total += $entry.Length }
    if ($total -gt 128MB) { throw 'Archive exceeds the 128 MiB import limit.' }
    $images = @($zip.Entries | Where-Object { $_.FullName.EndsWith('.img', [StringComparison]::OrdinalIgnoreCase) })
    if ($images.Count -ne 1) { throw 'Select the original Dune II ISO-Version ZIP containing one .img file.' }
    if ($images[0].Length -gt 64MB -or $images[0].Length -lt 17 * 2352 -or $images[0].Length % 2352 -ne 0) {
        throw 'Expected a complete MODE1/2352 CD image of at most 64 MiB.'
    }
    $raw = New-Object byte[] ([int]$images[0].Length)
    $stream = $images[0].Open()
    try {
        $position = 0
        while ($position -lt $raw.Length) {
            $count = $stream.Read($raw, $position, $raw.Length - $position)
            if ($count -eq 0) { throw 'Truncated CD image.' }
            $position += $count
        }
    } finally { $stream.Dispose() }
} finally { $zip.Dispose() }
$iso = New-Object byte[] ([int]($raw.Length / 2352 * 2048))
for ($sector = 0; $sector -lt $raw.Length / 2352; $sector++) {
    [Buffer]::BlockCopy($raw, $sector * 2352 + 16, $iso, $sector * 2048, 2048)
}
if ($iso[16 * 2048] -ne 1 -or [Text.Encoding]::ASCII.GetString($iso, 16 * 2048 + 1, 5) -ne 'CD001' -or
    $iso[16 * 2048 + 6] -ne 1) { throw 'The CD image is not a supported ISO9660 volume.' }

function Get-Extent([int]$Record) {
    if ($Record -lt 0 -or $Record + 34 -gt $iso.Length) { throw 'Invalid ISO record.' }
    $start = [long][BitConverter]::ToUInt32($iso, $Record + 2) * 2048
    $size = [long][BitConverter]::ToUInt32($iso, $Record + 10)
    if ($start + $size -gt $iso.Length) { throw 'ISO extent outside image.' }
    [pscustomobject]@{ Start = [int]$start; Size = [int]$size }
}
function Get-Directory([int]$Record) {
    $extent = Get-Extent $Record
    $position = $extent.Start
    $end = $position + $extent.Size
    $names = @{}
    while ($position -lt $end) {
        $length = [int]$iso[$position]
        if ($length -eq 0) { $position = ([int][Math]::Floor($position / 2048) + 1) * 2048; continue }
        if ($length -lt 34 -or $position + $length -gt $end -or 33 + $iso[$position + 32] -gt $length) {
            throw 'Invalid ISO directory entry.'
        }
        $nameLength = [int]$iso[$position + 32]
        if ($nameLength -ne 1 -or $iso[$position + 33] -gt 1) {
            $name = [Text.Encoding]::ASCII.GetString($iso, $position + 33, $nameLength).Split(';')[0].ToLowerInvariant()
            if ($names.ContainsKey($name)) { throw "Duplicate ISO entry: $name" }
            $names[$name] = $true
            $entry = Get-Extent $position
            [pscustomobject]@{ Name = $name; Record = $position; Start = $entry.Start; Size = $entry.Size;
                              Directory = (($iso[$position + 25] -band 2) -ne 0) }
        }
        $position += $length
    }
}

$directory = 16 * 2048 + 156
foreach ($name in @('virgin', 'dune2')) {
    $matches = @(Get-Directory $directory | Where-Object { $_.Name -eq $name -and $_.Directory })
    if ($matches.Count -ne 1) { throw "Required CD directory not found: $name" }
    $directory = $matches[0].Record
}
$required = @('atre.pak', 'dune.pak', 'english.pak', 'finale.pak', 'hark.pak', 'intro.pak',
              'introvoc.pak', 'mentat.pak', 'merc.pak', 'ordos.pak', 'scenario.pak', 'sound.pak', 'voc.pak')
$allowed = $required + @('french.pak', 'german.pak', 'dune2.exe')
$selected = @(Get-Directory $directory | Where-Object { !$_.Directory -and $allowed -contains $_.Name })
foreach ($name in $required) {
    if (@($selected | Where-Object { $_.Name -eq $name -and $_.Size -gt 0 }).Count -ne 1) {
        throw "Required resource missing: $name"
    }
}
$parent = Split-Path $destinationPath -Parent
New-Item -ItemType Directory -Force -Path $parent | Out-Null
$stage = Join-Path $parent ('.dune-import-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $stage | Out-Null
try {
    $files = [ordered]@{}
    foreach ($entry in ($selected | Sort-Object Name)) {
        $path = Join-Path $stage $entry.Name
        $output = [IO.File]::Open($path, [IO.FileMode]::CreateNew)
        try { $output.Write($iso, $entry.Start, $entry.Size) } finally { $output.Dispose() }
        $files[$entry.Name] = @{ size = $entry.Size; sha256 = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() }
    }
    $manifest = @{ game = 'dune2'; source_sha256 = (Get-FileHash -LiteralPath $Archive -Algorithm SHA256).Hash.ToLowerInvariant();
                   files = $files; status = 'assets imported; native engine validation required' }
    $manifest | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $stage 'manifest.json') -Encoding UTF8
    [IO.Directory]::Move($stage, $destinationPath)
} finally {
    if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force }
}
Write-Host "Imported $($selected.Count) files to $destinationPath. No DOS program was executed."
