$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$exe = "$root/build-windows/bin/Release/nax-dune.exe"
if (Test-Path "$root/nax-dune.exe") { $exe = "$root/nax-dune.exe" }
if (!(Test-Path $exe)) { throw 'Build or extract the Windows executable first.' }
& (Join-Path $PSScriptRoot 'play-dune.ps1') -PrepareOnly
$settings = Join-Path $env:LOCALAPPDATA 'NaxGameRestoration/Dune2/opendune.ini'
$encoding = [Text.Encoding]::GetEncoding([Globalization.CultureInfo]::CurrentCulture.TextInfo.ANSICodePage)
$data = $null
$section = $false
foreach ($line in ([IO.File]::ReadAllText($settings, $encoding) -split '\r?\n')) {
    if ($line -match '^\s*\[([^]]+)\]') { $section = $Matches[1] -ieq 'opendune' }
    elseif ($section -and $line -match '^\s*datadir\s*=(.*)$') { $data = $Matches[1].Trim() }
}
if (!$data) { throw 'The launcher did not provide a game data directory.' }
$run = Join-Path $env:TEMP ('NaxDuneCheck-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory $run | Out-Null
@"
[opendune]
datadir=$($data.Replace('\','/'))
savedir=.
language=english
scalefactor=3
scalefilter=nearest
"@ | Set-Content -Encoding ascii "$run/opendune.ini"
$names = @('NAX_SMOKE_FRAMES', 'NAX_SMOKE_OUTPUT', 'NAX_VALIDATE_SCENARIOS', 'NAX_DATA_DIR', 'NAX_SAVE_DIR')
$previous = @{}
foreach ($name in $names) { $previous[$name] = [Environment]::GetEnvironmentVariable($name, 'Process') }
try {
    foreach ($name in $names) { [Environment]::SetEnvironmentVariable($name, $null, 'Process') }
    $env:NAX_DATA_DIR = $data
    $env:NAX_SAVE_DIR = $run
    foreach ($mode in @('intro', 'scenarios')) {
        $env:NAX_SMOKE_FRAMES = $null
        $env:NAX_SMOKE_OUTPUT = $null
        $env:NAX_VALIDATE_SCENARIOS = $null
        if ($mode -eq 'intro') {
            $env:NAX_SMOKE_FRAMES = '10'
            $env:NAX_SMOKE_OUTPUT = "$run/intro.bmp"
        } else { $env:NAX_VALIDATE_SCENARIOS = '1' }
        $process = Start-Process -FilePath $exe -WorkingDirectory $run -PassThru
        if (!$process.WaitForExit(30000)) { $process.Kill(); throw "$mode check timed out. Logs: $run" }
        $process.Refresh()
        if ($process.ExitCode -ne 0) { throw "$mode check failed. Logs: $run" }
        $log = Get-Content "$run/error.log" -Raw
        if ($log -notmatch 'Nax renderer: direct3d12') { throw 'Direct3D 12 was not confirmed.' }
        if ($mode -eq 'intro' -and $log -notmatch 'NAX_SMOKE frames=10 nonblack_pixels=[1-9][0-9]*') {
            throw 'Intro rendered no confirmed nonblack frame.'
        }
        if ($mode -eq 'scenarios' -and $log -notmatch 'NAX_SCENARIOS_OK count=3') {
            throw 'Scenario loading did not complete.'
        }
        Copy-Item "$run/error.log" "$run/$mode.log"
        Write-Host "$mode passed with Direct3D 12."
    }
    Write-Host "Evidence retained at $run. Audio and interactive controls still require a manual check."
} finally {
    foreach ($name in $names) { [Environment]::SetEnvironmentVariable($name, $previous[$name], 'Process') }
}
