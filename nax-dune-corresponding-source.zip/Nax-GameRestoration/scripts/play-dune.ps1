param([string]$Archive, [switch]$PrepareOnly)
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$exe = Join-Path $root 'build-windows/bin/Release/nax-dune.exe'
if (Test-Path -LiteralPath (Join-Path $root 'nax-dune.exe')) { $exe = Join-Path $root 'nax-dune.exe' }
if (!(Test-Path -LiteralPath $exe)) { throw 'Extract the complete Windows package or run scripts/build-windows.ps1 first.' }
$run = Join-Path $env:LOCALAPPDATA 'NaxGameRestoration/Dune2'
$ini = Join-Path $run 'opendune.ini'
$encoding = [Text.Encoding]::GetEncoding([Globalization.CultureInfo]::CurrentCulture.TextInfo.ANSICodePage,
    [Text.EncoderFallback]::ExceptionFallback, [Text.DecoderFallback]::ExceptionFallback)
$content = if (Test-Path -LiteralPath $ini) { [IO.File]::ReadAllText($ini, $encoding) } else { @"
[opendune]
language=english
scalefactor=3
scalefilter=nearest
fullscreen=0
framerate=60
dune2_enhanced=1
"@ }
$previousData = $null
$saveDirectory = '.'
$inSection = $false
foreach ($line in ($content -split '\r?\n')) {
    if ($line -match '^\s*\[([^]]+)\]') { $inSection = $Matches[1] -ieq 'opendune' }
    elseif ($inSection -and $line -match '^\s*datadir\s*=(.*)$') { $previousData = $Matches[1].Trim() }
    elseif ($inSection -and $line -match '^\s*savedir\s*=(.*)$') { $saveDirectory = $Matches[1].Trim() }
}
if ($previousData -and ![IO.Path]::IsPathRooted($previousData)) { $previousData = Join-Path $run $previousData }
$required = @('atre.pak', 'dune.pak', 'english.pak', 'finale.pak', 'hark.pak', 'intro.pak',
              'introvoc.pak', 'mentat.pak', 'merc.pak', 'ordos.pak', 'scenario.pak', 'sound.pak', 'voc.pak')
function Test-GameData([string]$Folder) {
    foreach ($name in $required) {
        if (!(Test-Path -LiteralPath (Join-Path $Folder $name) -PathType Leaf)) { return $false }
    }
    return $true
}
$data = $null
$candidates = @()
if ($previousData) { $candidates += $previousData }
$candidates += @((Join-Path $run 'data'), (Join-Path $root 'local-data/dune2'), (Join-Path $root 'data'))
foreach ($candidate in $candidates) {
    if (Test-GameData $candidate) { $data = $candidate; break }
}
if (!$data) {
    if (!$Archive) {
        Add-Type -AssemblyName System.Windows.Forms
        $dialog = New-Object System.Windows.Forms.OpenFileDialog
        $dialog.Title = 'Select your original Dune II ISO-Version ZIP (game data is not included)'
        $dialog.Filter = 'Dune II ZIP archive (*.zip)|*.zip'
        try {
            if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
                Write-Host 'Cancelled. Original Dune II data is required.'
                exit 1
            }
            $Archive = $dialog.FileName
        } finally { $dialog.Dispose() }
    }
    $data = Join-Path $run 'data'
    # Preserve incomplete imports too. Import into a fresh directory instead.
    if (Test-Path -LiteralPath $data) { $data = Join-Path $run ('data-' + [guid]::NewGuid().ToString('N')) }
    & (Join-Path $PSScriptRoot 'import-dune.ps1') -Archive $Archive -Destination $data
    if (!(Test-GameData $data)) { throw 'Import did not provide all required resources.' }
}
New-Item -ItemType Directory -Force -Path $run | Out-Null
# Refresh paths on every launch; preserve other settings and existing saves.
$lines = New-Object 'System.Collections.Generic.List[string]'
$inSection = $false
$found = $false
foreach ($line in ($content -split '\r?\n')) {
    if ($line -match '^\s*\[([^]]+)\]') {
        $inSection = $Matches[1] -ieq 'opendune'
        if ($inSection) {
            $found = $true
            $lines.Add($line)
            $lines.Add('datadir=' + $data.Replace('\','/'))
            $lines.Add('savedir=' + $saveDirectory)
            continue
        }
    }
    if ($inSection -and $line -match '^\s*(datadir|savedir)\s*=') { continue }
    $lines.Add($line)
}
if (!$found) { $lines.Add('[opendune]'); $lines.Add('datadir=' + $data.Replace('\','/')); $lines.Add('savedir=' + $saveDirectory) }
$bytes = $encoding.GetBytes(($lines -join "`r`n") + "`r`n")
if ((Test-Path -LiteralPath $ini) -and !(Test-Path -LiteralPath ($ini + '.before-launcher-update'))) {
    Copy-Item -LiteralPath $ini -Destination ($ini + '.before-launcher-update')
}
[IO.File]::WriteAllBytes($ini, $bytes)
Write-Host "Game data: $data"
if ($PrepareOnly) { return }
$previousDataEnv = $env:NAX_DATA_DIR
$previousSaveEnv = $env:NAX_SAVE_DIR
Push-Location -LiteralPath $run
try {
    $env:NAX_DATA_DIR = $data
    $env:NAX_SAVE_DIR = if ([IO.Path]::IsPathRooted($saveDirectory)) { $saveDirectory } else { Join-Path $run $saveDirectory }
    & $exe
    if ($LASTEXITCODE -ne 0) { throw "Dune II exited with $LASTEXITCODE. See $run/error.log" }
} finally {
    $env:NAX_DATA_DIR = $previousDataEnv
    $env:NAX_SAVE_DIR = $previousSaveEnv
    Pop-Location
}
