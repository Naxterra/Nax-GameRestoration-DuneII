"""Package native binaries and corresponding source, excluding local game data."""
import argparse
import os
from pathlib import Path
import zipfile


def add_tree(archive, root, prefix):
    for directory, dirs, files in os.walk(root):
        dirs[:] = sorted(d for d in dirs if d not in
                         {'.git', '__pycache__', 'local-data', 'artifacts'} and
                         (not d.startswith('build') or d == 'build-scripts'))
        for name in sorted(files):
            file = Path(directory)/name
            if name.endswith(('.pyc', '.bmp', '.res')):
                continue
            archive.write(file, str(Path(prefix)/file.relative_to(root)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bin-dir', type=Path, required=True)
    parser.add_argument('--sdl-source', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, default=Path('artifacts'))
    parser.add_argument('--cross-tools-root', type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    for file in (args.bin_dir/'nax-dune.exe', args.bin_dir/'SDL2.dll', args.sdl_source/'LICENSE.txt'):
        if not file.is_file():
            parser.error(f'Missing build input: {file}')
    args.output_dir.mkdir(parents=True, exist_ok=True)
    sources = args.output_dir/'nax-dune-corresponding-source.zip'
    with zipfile.ZipFile(sources, 'w', zipfile.ZIP_DEFLATED) as archive:
        add_tree(archive, root, 'Nax-GameRestoration')
        add_tree(archive, args.sdl_source, 'dependencies/SDL2-2.32.10')
        if args.cross_tools_root:
            for name in ('windows-toolchain.cmake', 'zig-rules.cmake', 'wrappers/zig-cc', 'wrappers/zig-windres'):
                archive.write(args.cross_tools_root/name, 'cross-build-support/'+name)
            archive.writestr('cross-build-support/README.txt',
                'These are the exact helper scripts used for the Linux-hosted Windows build.\n'
                'Tools: Zig 0.14.1 (pip ziglang), CMake 4.4.4, GNU Make.\n'
                'Recorded /workspace paths refer to the build machine; adapt them to reuse.\n'
                'Configure with -DCMAKE_TOOLCHAIN_FILE=windows-toolchain.cmake and then build.\n')
        archive.writestr('BUILD.txt',
            'See Nax-GameRestoration/README.md for the native Windows build.\n'
            'To use the bundled SDL2 source offline, pass this CMake option:\n'
            '-DFETCHCONTENT_SOURCE_DIR_SDL2=/absolute/path/to/dependencies/SDL2-2.32.10\n')
    binary = args.output_dir/'nax-dune-windows-x64.zip'
    with zipfile.ZipFile(binary, 'w', zipfile.ZIP_DEFLATED) as archive:
        for name in ('nax-dune.exe', 'SDL2.dll'):
            archive.write(args.bin_dir/name, name)
        for name in ('README.md', 'THIRD_PARTY.md', 'LICENSE'):
            archive.write(root/name, name)
        for file in (root/'scripts').glob('*.ps1'):
            archive.write(file, 'scripts/'+file.name)
        archive.write(root/'tools/import_assets.py', 'tools/import_assets.py')
        archive.write(args.sdl_source/'LICENSE.txt', 'licenses/SDL2-LICENSE.txt')
        archive.writestr('SOURCE.txt', 'Corresponding source: nax-dune-corresponding-source.zip\n'
                          'Original game assets are imported separately; see README.md.\n'
                          'Windows 11 runtime and DX12 GPU tests are still required.\n')
    for file in (binary, sources):
        with zipfile.ZipFile(file) as archive:
            if archive.testzip() is not None:
                raise RuntimeError(f'Corrupt package: {file}')
        print(file.resolve())


if __name__ == '__main__':
    main()
