# Third-party code

`third_party/opendune` is vendored from https://github.com/OpenDUNE/OpenDUNE
at commit `ebea79aeba025be2fe9004570e9255044aacc0be`.
Its original authors and notices are retained, including the GNU GPL v2 license
in `third_party/opendune/COPYING`. The SDL2 video backend is modified for strict
Direct3D 12 selection on Windows, resizing, desktop fullscreen, DPI awareness,
full-frame nearest-neighbor uploads, and an optional rendering smoke check.
The root CMake build replaces the upstream platform build configuration.
`src/opendune.c` adds a scenario-validation mode; `src/os/error_win32.c`
restarts varargs before sending formatted messages to the Windows log.
`src/file.c` accepts launcher data/save directory overrides and reports missing
original PAK files with startup instructions.

New project code is also provided under GPL v2; see LICENSE.

SDL2 release 2.32.10 is fetched at commit
`5d249570393f7a37e037abf22cd6012a4cc56a71` from
https://github.com/libsdl-org/SDL, under its zlib license. Include SDL's LICENSE.txt
when distributing binaries. Source and license obligations for the GPL engine
also apply to distribution; retain and provide the corresponding source.

Original game executables, graphics, sound, maps and text remain separate local
data. They are not included in source or build artifacts. The importer never
executes the DOS programs. Reading legacy resource formats is not DOS emulation.
