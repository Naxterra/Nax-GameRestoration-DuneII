import importlib.util
from pathlib import Path
import tempfile
import unittest
import zipfile

spec = importlib.util.spec_from_file_location("assets", Path(__file__).parents[1] / "tools/import_assets.py")
assets = importlib.util.module_from_spec(spec)
spec.loader.exec_module(assets)


def image_with_file(payload=b"original data"):
    iso = bytearray(24 * 2048)
    def record(name, sector, size, directory=False):
        r = bytearray(33 + len(name) + (len(name) % 2 == 0))
        r[0] = len(r)
        r[2:6] = sector.to_bytes(4, "little")
        r[10:14] = size.to_bytes(4, "little")
        r[25] = 2 if directory else 0
        r[32] = len(name)
        r[33:33+len(name)] = name
        return r
    iso[16*2048:16*2048+7] = b"\x01CD001\x01"
    root = record(b"\0", 20, 2048, True)
    iso[16*2048+156:16*2048+156+len(root)] = root
    entry = record(b"FILE.PAK;1", 21, len(payload))
    iso[20*2048:20*2048+len(entry)] = entry
    iso[21*2048:21*2048+len(payload)] = payload
    return b"".join(b"\0"*16 + iso[n:n+2048] + b"\0"*288 for n in range(0,len(iso),2048))


class ImportTests(unittest.TestCase):
    def test_raw_cd_preserves_file_bytes(self):
        self.assertEqual(assets.iso_files(image_with_file()), {"file.pak": b"original data"})

    def test_truncated_or_unknown_cd_rejected(self):
        for raw in (image_with_file()[:-1], bytes(2352*24)):
            with self.assertRaises(ValueError):
                assets.iso_files(raw)

    def test_out_of_range_extent_rejected(self):
        raw = bytearray(image_with_file())
        pos = 20*2352+16+2
        raw[pos:pos+4] = (9999).to_bytes(4,"little")
        with self.assertRaises(ValueError):
            assets.iso_files(raw)

    def test_zip_traversal_and_duplicate_names_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            archive = Path(tmp)/"bad.zip"
            for names in (("../escape",), ("utopia/A", "UTOPIA/a")):
                with zipfile.ZipFile(archive,"w") as z:
                    for name in names:
                        z.writestr(name,b"data")
                with self.assertRaises(ValueError):
                    assets.read_zip(archive)

    def test_import_hashes_and_existing_data_protected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            archive=root/"utopia.zip"
            with zipfile.ZipFile(archive,"w") as z:
                for name in ("utopia.exe", "u.mdg", "scenario/level1.map"):
                    z.writestr("utopia/"+name,b"fixture")
            m=assets.import_game("utopia",archive,root/"data")
            self.assertEqual(len(m["files"]),3)
            self.assertEqual((root/"data/utopia/scenario/level1.map").read_bytes(),b"fixture")
            (root/"data/utopia/u.mdg").write_bytes(b"preserve user file")
            with self.assertRaises(ValueError):
                assets.import_game("utopia",archive,root/"data")
            self.assertEqual((root/"data/utopia/u.mdg").read_bytes(),b"preserve user file")

    def test_no_partial_import_for_missing_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            archive=root/"utopia.zip"
            with zipfile.ZipFile(archive,"w") as z:
                z.writestr("utopia/utopia.exe",b"fixture")
            with self.assertRaises(ValueError):
                assets.import_game("utopia",archive,root/"data")
            self.assertFalse((root/"data/utopia").exists())
