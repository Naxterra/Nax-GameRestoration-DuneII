"""Exercise the real PowerShell importer and launcher preflight, without a GPU."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import tempfile
import unittest
import zipfile

ROOT = Path(__file__).resolve().parents[1]
PWSH = os.environ.get('NAX_PWSH') or shutil.which('pwsh')
REQUIRED = ('atre.pak dune.pak english.pak finale.pak hark.pak intro.pak '
            'introvoc.pak mentat.pak merc.pak ordos.pak scenario.pak sound.pak voc.pak').split()


def cd_image(files):
    data = bytearray((24 + len(files)) * 2048)
    def record(name, sector, size, directory=False):
        name = name.encode('ascii')
        r = bytearray(33 + len(name) + (len(name) % 2 == 0))
        r[0] = len(r)
        struct.pack_into('<I', r, 2, sector)
        struct.pack_into('<I', r, 10, size)
        r[25] = 2 if directory else 0
        r[32] = len(name)
        r[33:33+len(name)] = name
        return r
    data[16*2048:16*2048+7] = b'\x01CD001\x01'
    root = record('\0', 20, 2048, True)
    data[16*2048+156:16*2048+156+len(root)] = root
    for sector, entry in ((20, record('VIRGIN',21,2048,True)),
                          (21, record('DUNE2',22,2048,True))):
        data[sector*2048:sector*2048+len(entry)] = entry
    position = 22 * 2048
    for i, (name, content) in enumerate(files.items()):
        sector = 24+i
        entry = record(name.upper()+';1', sector, len(content))
        data[position:position+len(entry)] = entry
        position += len(entry)
        data[sector*2048:sector*2048+len(content)] = content
    return b''.join(b'\0'*16 + data[n:n+2048] + b'\0'*288 for n in range(0,len(data),2048))


@unittest.skipUnless(PWSH, 'PowerShell is required for Windows startup integration tests')
class WindowsStartupTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='nax startup [test] ')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.env = os.environ.copy()
        for name in ('XDG_CACHE_HOME','XDG_CONFIG_HOME','XDG_DATA_HOME'):
            self.env[name] = str(self.root/name)
        self.env['LOCALAPPDATA'] = str(self.root/'app data')

    def run_script(self, script, *args):
        return subprocess.run([PWSH,'-NoProfile','-File',str(script),*map(str,args)],
                              env=self.env,capture_output=True,text=True,timeout=30,cwd=self.root)

    def archive(self, files, duplicate=False):
        archive=self.root/'original CD.zip'
        with zipfile.ZipFile(archive,'w') as z:
            raw=cd_image(files)
            z.writestr('Dune 2 - ISO/DUNE2CD.img',raw)
            if duplicate:z.writestr('second.img',raw)
        return archive

    def test_import_preserves_bytes_and_refuses_overwrite(self):
        files={name:('fixture '+name).encode() for name in REQUIRED}
        archive=self.archive(files)
        target=self.root/'imported'
        result=self.run_script(ROOT/'scripts/import-dune.ps1','-Archive',archive,'-Destination',target)
        self.assertEqual(result.returncode,0,result.stderr)
        manifest=json.loads((target/'manifest.json').read_text(encoding='utf-8-sig'))
        for name,content in files.items():
            self.assertEqual((target/name).read_bytes(),content)
            self.assertEqual(manifest['files'][name]['sha256'],hashlib.sha256(content).hexdigest())
        (target/'dune.pak').write_bytes(b'preserve local data')
        result=self.run_script(ROOT/'scripts/import-dune.ps1','-Archive',archive,'-Destination',target)
        self.assertNotEqual(result.returncode,0)
        self.assertEqual((target/'dune.pak').read_bytes(),b'preserve local data')

    def test_incomplete_disc_or_multiple_images_leave_no_import(self):
        for duplicate in (False,True):
            archive=self.archive({'dune.pak':b'not enough'},duplicate)
            target=self.root/'missing resources'
            result=self.run_script(ROOT/'scripts/import-dune.ps1','-Archive',archive,'-Destination',target)
            self.assertNotEqual(result.returncode,0)
            self.assertFalse(target.exists())

    def make_package(self):
        package=self.root/'package [new]'
        (package/'scripts').mkdir(parents=True)
        for name in ('play-dune.ps1','import-dune.ps1'):
            shutil.copy2(ROOT/'scripts'/name,package/'scripts'/name)
        (package/'nax-dune.exe').write_bytes(b'not executed: preflight only')
        return package

    def test_launcher_repairs_moved_data_path_and_preserves_settings_and_saves(self):
        package=self.make_package()
        data=package/'local-data/dune2'
        data.mkdir(parents=True)
        for name in REQUIRED:(data/name).write_bytes(b'fixture')
        run=Path(self.env['LOCALAPPDATA'])/'NaxGameRestoration/Dune2'
        run.mkdir(parents=True)
        ini=run/'opendune.ini'
        original='[opendune]\ndatadir=/missing/old/package\nsavedir=custom-saves\nscalefactor=4\n[other]\ndatadir=preserve-other-section\n'
        ini.write_text(original)
        (run/'custom-saves').mkdir()
        save=run/'custom-saves/save.dat'
        save.write_bytes(b'player save')
        for _ in range(2):
            result=self.run_script(package/'scripts/play-dune.ps1','-PrepareOnly')
            self.assertEqual(result.returncode,0,result.stderr)
        text=ini.read_text()
        self.assertIn('datadir='+data.as_posix(),text)
        self.assertIn('scalefactor=4',text)
        self.assertIn('savedir=custom-saves',text)
        self.assertIn('[other]\ndatadir=preserve-other-section',text)
        self.assertEqual((run/'opendune.ini.before-launcher-update').read_text(),original)
        self.assertEqual(save.read_bytes(),b'player save')

    def test_launcher_imports_without_python_and_reuses_import(self):
        package=self.make_package()
        archive=self.archive({name:b'fixture' for name in REQUIRED})
        # Preserve an incomplete existing import and use a fresh data directory.
        run=Path(self.env['LOCALAPPDATA'])/'NaxGameRestoration/Dune2'
        (run/'data').mkdir(parents=True)
        (run/'data/user-file').write_bytes(b'preserve')
        result=self.run_script(package/'scripts/play-dune.ps1','-Archive',archive,'-PrepareOnly')
        self.assertEqual(result.returncode,0,result.stderr)
        result=self.run_script(package/'scripts/play-dune.ps1','-PrepareOnly')
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertEqual((run/'data/user-file').read_bytes(),b'preserve')
        self.assertEqual(len(list(run.glob('data-*/dune.pak'))),1)
